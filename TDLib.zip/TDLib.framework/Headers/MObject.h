//
//  MObject.h
//  DynamicLibrary
//
//  Created by hu min on 18/04/2017.
//  Copyright © 2017 hu min. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MObject : NSObject

+ (void)sayHello;

@end
