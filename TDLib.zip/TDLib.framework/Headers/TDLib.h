//
//  TDLib.h
//  TDLib
//
//  Created by hu min on 19/04/2017.
//  Copyright © 2017 hu min. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TDLib.
FOUNDATION_EXPORT double TDLibVersionNumber;

//! Project version string for TDLib.
FOUNDATION_EXPORT const unsigned char TDLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TDLib/PublicHeader.h>


#import <TDLib/MObject.h>
