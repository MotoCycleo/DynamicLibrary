//
//  TXObject.h
//  TXLib
//
//  Created by hu min on 11/04/2018.
//  Copyright © 2018 hu min. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <TYLib/TYLib.h>

@interface TXObject : NSObject

+ (void)txSayHello;
+ (void)callTyInsideTx;

@end
