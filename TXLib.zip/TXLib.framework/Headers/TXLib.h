//
//  TXLib.h
//  TXLib
//
//  Created by hu min on 19/04/2017.
//  Copyright © 2017 hu min. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TXLib.
FOUNDATION_EXPORT double TXLibVersionNumber;

//! Project version string for TXLib.
FOUNDATION_EXPORT const unsigned char TXLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TXLib/PublicHeader.h>

#import <TXLib/TXObject.h>

