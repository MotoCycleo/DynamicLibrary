//
//  TYLib.h
//  TYLib
//
//  Created by hu min on 19/04/2017.
//  Copyright © 2017 hu min. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TYLib.
FOUNDATION_EXPORT double TYLibVersionNumber;

//! Project version string for TYLib.
FOUNDATION_EXPORT const unsigned char TYLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TYLib/PublicHeader.h>

#import <TYLib/MObject.h>

